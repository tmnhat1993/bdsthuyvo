<?php 
if( !defined( 'ABSPATH') && !defined('WP_UNINSTALL_PLUGIN') )
	exit();

/*  
	If user remove plugin in order to upgrade it - it is not smart to delete plugin data :-)
*/
?>